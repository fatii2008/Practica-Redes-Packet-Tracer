**página de Albacete**

<html>

<head>

<title>Albacete</title>

</head>

<body>

<center>

<h1>Bienvenidos a Albacete</h1>

<p>Esta página muestra información sobre la ciudad de Albacete.</p>

<img src="albacete.jpg" width="400">

</center>

</body>

</html>

